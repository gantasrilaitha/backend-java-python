package com.example.employee.controller;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.File;

import javax.imageio.ImageIO;

import java.util.ArrayList;


import com.azure.core.http.rest.PagedIterable;
import com.azure.messaging.servicebus.ServiceBusClientBuilder;
import com.azure.messaging.servicebus.ServiceBusMessage;
import com.azure.messaging.servicebus.ServiceBusSenderClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.azure.storage.blob.models.BlobItem;
import com.azure.storage.blob.models.ListBlobsOptions;
import com.azure.storage.blob.sas.BlobContainerSasPermission;
import com.azure.storage.blob.sas.BlobServiceSasSignatureValues;
import com.azure.storage.blob.specialized.BlockBlobClient;
import com.example.employee.entity.Employee;
import com.example.employee.entity.EmployeeDetails;
import com.example.employee.exception.ResourceNotFoundException;
import com.example.employee.repository.EmployeeRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1")
public class EmployeeController {
    @Autowired
    private EmployeeRepository employeeRepository;
    ObjectMapper objectMapper = new ObjectMapper();
    @Value("${azure.storage.connectionstring}")
    private String storageConnectionString;
    
    @Value("${azure.servicebus.connectionstring}")
    private String serviceBusConnectionString;
    
    @Value("${azure.servicebus.queuename}")
    private String serviceBusQueueName;

    // get all employees
    @GetMapping("/employees")
    public List<EmployeeDetails> getAllEmployees() {
    	File inputFile = new File("C:\\Users\\xd4fne\\Downloads\\satya_nadella.jpg");
        BufferedImage inputImage;
		try {
			inputImage = ImageIO.read(inputFile);
		
 
        // creates output image
        BufferedImage outputImage = new BufferedImage(50,
                50, inputImage.getType());
 
        // scales the input image to the output image
        Graphics2D g2d = outputImage.createGraphics();
        g2d.drawImage(inputImage, 0, 0, 50, 50, null);
        g2d.dispose();
        String outputImagePath = "C:\\Users\\xd4fne\\Downloads\\satya_nadella_icon.jpg";
        // extracts extension of output file
        String formatName = outputImagePath.substring(outputImagePath
                .lastIndexOf(".") + 1);
 
        // writes to output file
        ImageIO.write(outputImage, "jpg", new File(outputImagePath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
    	List<Employee> employees = employeeRepository.findAll();
    	List<EmployeeDetails> employeeDetails = new ArrayList<EmployeeDetails>();
    	for (int cnt = 0; cnt < employees.size(); cnt++) {
    		System.out.println(employees.get(cnt).getId());
    		Employee employee = employees.get(cnt);
    		String fileName = employee.getFirstName() + "_" + employee.getLastName();
        	String blobSasUrl = this.getEmployeePhotoUrl(fileName);
        	String blobIconSasUrl = this.getEmployeeIconPhotoUrl(fileName);
        	EmployeeDetails employeeDetail = new EmployeeDetails(employee.getFirstName(), employee.getLastName(), employee.getEmailId(),
        			employee.getPhoneNumber(), employee.getCity(), blobSasUrl, blobIconSasUrl);
        	employeeDetail.setId(employees.get(cnt).getId());
        	employeeDetails.add(employeeDetail);
    	}
        return employeeDetails;
    }

    // create employee rest API
    @PostMapping("/employees")
    public Employee createEmployee(@RequestParam("model") String employee, @RequestParam("file") MultipartFile file) {
    	Employee employeeDetails = null;
    	
    	
		try {
			System.out.println(employee);
			employeeDetails = objectMapper.readValue(employee, Employee.class);
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String fileName = employeeDetails.getFirstName() + "_" + employeeDetails.getLastName();
		// Upload profile photo to azure blob container.
		boolean isUploaded = uploadFileToAzureBlob(file, fileName);
		if (!isUploaded) {
    		throw new ResponseStatusException(
    		           HttpStatus.INTERNAL_SERVER_ERROR, "Error uploading photo");
    	}
        
		Employee savedEmployee = employeeRepository.save(employeeDetails);
		// create a Service Bus Sender client for the queue 
	    ServiceBusSenderClient senderClient = new ServiceBusClientBuilder()
	            .connectionString(serviceBusConnectionString)
	            .sender()
	            .queueName(serviceBusQueueName)
	            .buildClient();

	    // send one message to the queue
	    senderClient.sendMessage(new ServiceBusMessage(employeeDetails.getEmailId()));
	    
	    return savedEmployee;
    }

    // get employee by id rest api
    @GetMapping("/employees/{id}")
    public ResponseEntity<EmployeeDetails> getEmployeeById(@PathVariable Long id) {

    	Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException
                      ("Employee not exist with id :" + id));
    	String fileName = employee.getFirstName() + "_" + employee.getLastName();
    	String blobSasUrl = this.getEmployeePhotoUrl(fileName);
    	String blobIconSasUrl = this.getEmployeeIconPhotoUrl(fileName);
    	EmployeeDetails employeeDetails = new EmployeeDetails(employee.getFirstName(), employee.getLastName(), employee.getEmailId(),
    			employee.getPhoneNumber(), employee.getCity(), blobSasUrl, blobIconSasUrl);
    	employeeDetails.setId(employee.getId());
        return ResponseEntity.ok(employeeDetails);
    }

    // update employee rest api
    @PutMapping("/employees/{id}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable Long id,
             @RequestBody Employee employeeDetails) {

        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException
                      ("Employee not exist with id :" + id));
        employee.setFirstName(employeeDetails.getFirstName());
        employee.setLastName(employeeDetails.getLastName());
        employee.setEmailId(employeeDetails.getEmailId());
        Employee updatedEmployee = employeeRepository.save(employee);

        return ResponseEntity.ok(updatedEmployee);
    }

    // delete employee rest api
    @DeleteMapping("/employees/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteEmployee
               (@PathVariable Long id) {

        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException
                    ("Employee not exist with id :" + id));

        employeeRepository.delete(employee);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);

        return ResponseEntity.ok(response);
    }
    
    private boolean uploadFileToAzureBlob(MultipartFile file, String fileName) {
		
    	BlobServiceClient blobServiceClient = new BlobServiceClientBuilder()
    		    .connectionString(storageConnectionString)
    		    .buildClient();
    	// Create a unique name for the container
    	String containerName = "photos";

    	// Create the container and return a container client object
    	BlobContainerClient blobContainerClient = blobServiceClient.getBlobContainerClient(containerName);
    	if (!blobContainerClient.exists()) {
    		blobContainerClient.create();
    	}
    	
    	boolean isSuccess = true;
    	String fileExtension = StringUtils.getFilenameExtension(file.getOriginalFilename());
        String filename = fileName + '.' + fileExtension;
        BlockBlobClient blockBlobClient = blobContainerClient.getBlobClient(filename).getBlockBlobClient();
        try {
            // delete file if already exists in that container
            if (blockBlobClient.exists()) {
                blockBlobClient.delete();
            }
            // upload file to azure blob storage
            blockBlobClient.upload(new BufferedInputStream(file.getInputStream()), file.getSize(), true);
        } catch (IOException e) {
            isSuccess = false;
        }
        return isSuccess;
    }
    
    private String getEmployeePhotoUrl(String fileName) {
    	BlobServiceClient blobServiceClient = new BlobServiceClientBuilder()
    		    .connectionString(storageConnectionString)
    		    .buildClient();
    	// Create a unique name for the container
    	String containerName = "photos";
    	BlobContainerClient blobContainerClient = blobServiceClient.getBlobContainerClient(containerName);
    	if (!blobContainerClient.exists()) {
    		return "";
    	}
    	
    	//String blobFileName = "";
    	final List<String> blobFileName = new ArrayList<String>();
    	 //List<String> list=new ArrayList<String>();  
    	PagedIterable<BlobItem> blobs = blobContainerClient.listBlobs(new ListBlobsOptions().setPrefix(fileName), null);
    	blobs.forEach(blob -> { blobFileName.add(blob.getName());});
    	
    	if (blobFileName.size() == 0) {
    		return "";
    	}
    	
    	String url = "";
    	BlockBlobClient blockBlobClient = blobContainerClient.getBlobClient(blobFileName.get(0)).getBlockBlobClient();
        // delete file if already exists in that container
		if (!blockBlobClient.exists()) {
		    return "";
		}
		OffsetDateTime expiryTime = OffsetDateTime.now().plusHours(1);
		BlobContainerSasPermission permission = new BlobContainerSasPermission().setReadPermission(true);

		BlobServiceSasSignatureValues values = new BlobServiceSasSignatureValues(expiryTime, permission)
		    .setStartTime(OffsetDateTime.now());
		// upload file to azure blob storage
		url = blockBlobClient.generateSas(values);
    	url = blockBlobClient.getAccountUrl() + "/" + blockBlobClient.getContainerName() + "/" + blockBlobClient.getBlobName() + "?" + url;
    	return url;
    }
    
    private String getEmployeeIconPhotoUrl(String fileName) {
    	BlobServiceClient blobServiceClient = new BlobServiceClientBuilder()
    		    .connectionString(storageConnectionString)
    		    .buildClient();
    	// Create a unique name for the container
    	String containerName = "test-output-java";
    	BlobContainerClient blobContainerClient = blobServiceClient.getBlobContainerClient(containerName);
    	if (!blobContainerClient.exists()) {
    		return "";
    	}
    	
    	//String blobFileName = "";
    	final List<String> blobFileName = new ArrayList<String>();
    	 //List<String> list=new ArrayList<String>();  
    	PagedIterable<BlobItem> blobs = blobContainerClient.listBlobs(new ListBlobsOptions().setPrefix(fileName), null);
    	blobs.forEach(blob -> { blobFileName.add(blob.getName());});
    	
    	if (blobFileName.size() == 0) {
    		return "";
    	}
    	
    	String url = "";
    	BlockBlobClient blockBlobClient = blobContainerClient.getBlobClient(blobFileName.get(0)).getBlockBlobClient();
        // delete file if already exists in that container
		if (!blockBlobClient.exists()) {
		    return "";
		}
		OffsetDateTime expiryTime = OffsetDateTime.now().plusHours(1);
		BlobContainerSasPermission permission = new BlobContainerSasPermission().setReadPermission(true);

		BlobServiceSasSignatureValues values = new BlobServiceSasSignatureValues(expiryTime, permission)
		    .setStartTime(OffsetDateTime.now());
		// upload file to azure blob storage
		url = blockBlobClient.generateSas(values);
    	url = blockBlobClient.getAccountUrl() + "/" + blockBlobClient.getContainerName() + "/" + blockBlobClient.getBlobName() + "?" + url;
    	return url;
    }
}