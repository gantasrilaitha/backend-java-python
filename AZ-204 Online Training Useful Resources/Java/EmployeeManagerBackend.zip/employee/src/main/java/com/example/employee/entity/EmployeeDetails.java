package com.example.employee.entity;

public class EmployeeDetails extends Employee{

	    private String blobSasUrl;
	    private String blobIconSasUrl;

	    public EmployeeDetails(String firstName, String lastName, String emailId, String phoneNumber, String city, String blobSasUrl, String blobIconSasUrl) {
	        super(firstName, lastName, emailId, phoneNumber, city);
	 
	        this.blobSasUrl = blobSasUrl;
	        this.blobIconSasUrl = blobIconSasUrl;
	    }

	    public String getBlobSasUrl() {
	        return blobSasUrl;
	    }

	    public void setBlobSasUrl(String blobSasUrl) {
	        this.blobSasUrl = blobSasUrl;
	    }
	    
	    public String getBlobIconSasUrl() {
	        return blobIconSasUrl;
	    }

	    public void setBlobIconSasUrl(String blobIconSasUrl) {
	        this.blobIconSasUrl = blobIconSasUrl;
	    }

}
