package com.function.empphotoresize;

import com.microsoft.azure.functions.annotation.*;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import com.microsoft.azure.functions.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;

/**
 * Azure Functions with HTTP Trigger.
 */
public class Function {
    /**
     * This function listens at endpoint "/api/HttpExample". Two ways to invoke it using "curl" command in bash:
     * 1. curl -d "HTTP Body" {your host}/api/HttpExample
     * 2. curl "{your host}/api/HttpExample?name=HTTP%20Query"
     */
    @FunctionName("HttpExample")
    @StorageAccount("AzureWebJobsStorage")
    public void run(
        @BlobTrigger(name = "content", path = "photos/{name}", dataType = "binary") byte[] content,
        @BindingName("name") String fileName,
        @BlobInput(name = "inputBlob", path = "photos/{name}", dataType = "binary") byte[] inputBlob,
        @BlobOutput(name = "outputBlob", path = "test-output-java/{name}", dataType = "binary") OutputBinding<byte[]> outputBlob,
        final ExecutionContext context
    ) throws Exception {	        
	        ByteArrayInputStream inputFile = new ByteArrayInputStream(inputBlob);
	        BufferedImage inputImage;
			try {
				inputImage = ImageIO.read(inputFile);
			
	 
	        // creates output image
	        BufferedImage outputImage = new BufferedImage(50,
	                50, inputImage.getType());
	 
	        // scales the input image to the output image
	        Graphics2D g2d = outputImage.createGraphics();
	        g2d.drawImage(inputImage, 0, 0, 50, 50, null);
	        g2d.dispose();
	 
	        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
	        // writes to output file
	        ImageIO.write(outputImage, "jpg", outputStream);
	        byte[] photoIcon = outputStream.toByteArray();
	        outputBlob.setValue(photoIcon);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    }
}
